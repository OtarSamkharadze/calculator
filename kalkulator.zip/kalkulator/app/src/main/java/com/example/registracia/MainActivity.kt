package com.example.registracia

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {

    private lateinit var resultTextView: textView

    private var opperant: Double = 0.0




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        resultTextView = findViewById(R.id.resultTextView)

    }

    fun numberclick(clickedView: View) {

        if (clickedView is textView) {

            var result = resultTextView.text.toString()
            val number = clickedView.text.toString()

            if(result == "0") {
                result == ""
            }

            resultTextView.text = result + number

        }

    }

    fun operationClick (ClickedView: View) {

        if (clickedView is textView) {

            var result = resultTextView.text.toString()


        }

    }

}